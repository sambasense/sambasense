"""SambaSense CLI interface."""
