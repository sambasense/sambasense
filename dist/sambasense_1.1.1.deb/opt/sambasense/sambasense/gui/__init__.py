"""SambaSense GUI package."""
