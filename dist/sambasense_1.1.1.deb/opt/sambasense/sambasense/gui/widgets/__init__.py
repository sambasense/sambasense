"""SambaSense GUI widgets."""
