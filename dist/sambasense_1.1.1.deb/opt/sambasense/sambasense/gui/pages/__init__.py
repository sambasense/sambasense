"""SambaSense GUI pages."""
